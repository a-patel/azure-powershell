﻿
## To Set Verbose output
$PSDefaultParameterValues['*:Verbose'] = $true


<# Resource Group #>


# Variables - Resource Group

$rgShortName = "qweasdzxc"
$rgSuffix = "-rg"
$rgName = "${rgShortName}${rgSuffix}"




Get-AzureRmResourceGroup -Name $rgName -ErrorVariable isRGExist -ErrorAction SilentlyContinue `


if (!$isRGExist) 
{
    Write-Output "Resource Group (RG) exist"
    

    Write-Verbose "Deleting Resource Group: {$rgName}"

    Remove-AzureRmResourceGroup -Name $rgName -Force
} 
else 
{
    Write-Output "Resource Group (RG) does not exist"
}



Write-Verbose "Get list of Resource Groups"
Write-Output "Resource Groups"


Get-AzureRmResourceGroup `
    | Select-Object ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap -GroupBy Location



<#
## References

#>

