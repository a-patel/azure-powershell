﻿
## To Set Verbose output
$PSDefaultParameterValues['*:Verbose'] = $true


$rgShortName = "qweasdzxc"
$rgSuffix = "-rg"
$rgName = "${rgShortName}${rgSuffix}"



<# Disk (Managed) - Delete #>

<#


#>

# Variables - Disk (Managed)

$diskShortName = "TEST1"
$diskSuffix = "-DataDisk"
$diskName = "${diskShortName}${diskSuffix}"




Get-AzureRmDisk -Name $diskName -ResourceGroupName $rgName -ErrorVariable isDiskExist -ErrorAction SilentlyContinue `


if (!$isDiskExist) 
{
    Write-Output "Disk (Managed) exist"


    Write-Verbose "Deleting Data Disk: {$diskName}"

    $jobDiskDelete = Remove-AzureRmDisk -Name $diskName -ResourceGroupName $rgName -Force -AsJob

    $jobDiskDelete
} 
Else 
{
    Write-Output "Disk (Managed) does not exist"
}



Write-Verbose "Get list of Disks (Managed)"
Write-Output "Disks (Managed)"


Get-AzureRmDisk -ResourceGroupName $rgName `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap


<#
Get-AzureRmDisk `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap -GroupBy ResourceGroupName
#>



<#
# References

https://docs.microsoft.com/en-us/azure/virtual-machines/windows/tutorial-manage-data-disk

#>




