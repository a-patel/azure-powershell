﻿
<# Application Gateway - Remove #>


# Variables - Application Gateway

$agwShortName = "aabbccdd12"
$agwSuffix = "-agw"
$agwName = "${agwShortName}${agwSuffix}"




Get-AzureRmApplicationGateway -Name $agwName -ErrorVariable isAGWExist -ErrorAction SilentlyContinue `


If (!$isAGWExist) 
{
    Write-Output "Application Gateway (AG) exist"
    

    Write-Verbose "Removing Application Gateway (AG): {$agwName}"

    Remove-AzureRmApplicationGateway -Name $agwName -ResourceGroupName $rgName  -Force
} 
Else 
{
    Write-Output "Application Gateway (AG) does not exist"
}



Write-Verbose "Get list of Application Gateway"

Write-Output "Application Gateways"


Get-AzureRmApplicationGateway -ResourceGroupName $rgName `
| Select-Object Name, ResourceGroupName, Location `
| Format-Table -AutoSize -Wrap



<#

Get-AzureRmApplicationGateway `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap -GroupBy ResourceGroupName

#>





<#

https://docs.microsoft.com/en-us/azure/application-gateway/application-gateway-create-gateway-arm
https://docs.microsoft.com/en-us/powershell/module/azurerm.network/remove-azurermapplicationgateway?view=azurermps-6.13.0

#>

