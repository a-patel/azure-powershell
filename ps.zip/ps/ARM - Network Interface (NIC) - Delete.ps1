

## To Set Verbose output
$PSDefaultParameterValues['*:Verbose'] = $true


<# Network Interface (NIC) - Delete #>

<#


#>


# Variables - Network Interface (NIC)

$nicShortName = "qweasdzxc2"
$nicSuffix = "-nic"
$nicName = "${nicShortName}${nicSuffix}"



Get-AzureRmNetworkInterface -Name $nicName -ResourceGroupName $rgName -ErrorVariable isNICExist -ErrorAction SilentlyContinue `


if (!$isNICExist) 
{
    Write-Output "Network Interface (NIC) exist"

    
    Write-Verbose "Delete Network Interface (NIC): {$nicName}"

    Remove-AzureRmNetworkInterface -Name $nicName -ResourceGroupName $rgName -Force
} 
else 
{
    Write-Output "Network Interface (NIC) does not exist"
}




Write-Verbose "Get list of Network Interface (NIC)s"
Write-Output "Network Interface (NIC)s"


Get-AzureRmNetworkInterface -ResourceGroupName $rgName `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap

    
Get-AzureRmNetworkInterface -ResourceGroupName $rgName `
    | Select-Object -ExpandProperty IpConfigurations `
    | Select-Object Name, PrivateIpAddress `
    | Format-Table -AutoSize -Wrap
        


<#

Get-AzureRmNetworkInterface `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap -GroupBy ResourceGroupName

#>



<#
## References



#>




