﻿
<# Virtual Network (VNet) - Delete #>

<#


#>


# Variables - Virtual Network

$vnetShortName = "qweasdzxc"
$vnetSuffix = "-vnet"
$vnetName = "${vnetShortName}${vnetSuffix}"



Get-AzureRmVirtualNetwork -Name $vnetName -ResourceGroupName $rgName -ErrorVariable isVNetExist -ErrorAction SilentlyContinue `


if (!$isVNetExist) 
{
    Write-Output "Virtual Network (VNet) exist"
    

    Write-Verbose "Deleting Virtual Network (VNet): {$vnetName}"

    Remove-AzureRmVirtualNetwork -Name $vnetName -ResourceGroupName $rgName -Force
}
else 
{
    Write-Output "Virtual Network (VNet) does not exist"
}



Write-Verbose "Get list of all Virtual Network (VNet)"
Write-Output "Virtual Networks (VNet)"


Get-AzureRmVirtualNetwork -ResourceGroupName $rgName `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap 



# list of subnets
Get-AzureRmVirtualNetwork -ResourceGroupName $rgName `
    | Select-Object -ExpandProperty Subnets `
    | Select-Object Name, AddressPrefix `
    | Format-Table -AutoSize -Wrap 



<#

Get-AzureRmVirtualNetwork `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap -GroupBy ResourceGroupName 

#>




<#
## References


#>

