﻿

## To Set Verbose output
$PSDefaultParameterValues['*:Verbose'] = $true



# Variables - Resource Group

$rgShortName = "qweasdzxc"
$rgSuffix = "-rg"
$rgName = "${rgShortName}${rgSuffix}"


<# Virtul Machine (VM) - Delete #>

<#


#>

# Variables - Virtul Machine

$vmShortName = "Test"
$vmSuffix = "VM"
$vmName = "${vmShortName}${vmSuffix}"


Get-AzureRmVM -Name $vmName -ResourceGroupName $rgName -ErrorVariable isVMExist -ErrorAction SilentlyContinue `


if (!$isVMExist) 
{
    Write-Output "Virtul Machine (VM) exist"


    Write-Verbose "Deleting Virtul Machine: {$vmName}"

    $jobVMDelete = Remove-AzureRmVM -Name $vmName -ResourceGroupName $rgName -Force -AsJob

    $jobVMDelete
} 
else 
{
    Write-Output "Virtul Machine (VM) does not exist"
}



Write-Verbose "Get list of Virtul Machines"
Write-Output "Virtul Machines"


Get-AzureRmVM -ResourceGroupName $rgName `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap


<#

Get-AzureRmVM -ResourceGroupName $rgName `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap -GroupBy ResourceGroupName

#>



<#
## References



#>

