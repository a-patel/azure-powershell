﻿

## To Set Verbose output
$PSDefaultParameterValues['*:Verbose'] = $true



<# Load Balancer (LB) - Delete #>

<#


#>

# Variables - Load Balancer (LB)

$lbShortName = "qweasdzxc"
$lbSuffix = "-lb"
$lbName = "${lbShortName}${lbSuffix}"



Get-AzureRmLoadBalancer -Name $lbName -ResourceGroupName $rgName -ErrorVariable isLBExist -ErrorAction SilentlyContinue `


if (!$isLBExist) 
{
    Write-Output "Load Balancer exist"

    
    Write-Verbose "Deleting Load Balancer: {$lbName}"

    $jobLBDelete = Remove-AzureRmResourceGroup -Name $lbName -ResourceGroupName $rgName -Force -AsJob

    $jobLBDelete
} 
else 
{
    Write-Output "Load Balancer does not exist"
}



Write-Verbose "Get list of Load Balancers"
Write-Output "Load Balancers"


Get-AzureRmLoadBalancer `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap -GroupBy ResourceGroupName



<#
# References



#>


