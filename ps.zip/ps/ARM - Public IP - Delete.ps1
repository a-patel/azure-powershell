﻿
<# Public IP Address - Delete #>

<#


#>


# Variables - Public IP

$publicIpShortName = "qweasdzxc4"
$publicIpSuffix = "-ip"
$publicIpName = "${publicIpShortName}${publicIpSuffix}"


Get-AzureRmPublicIpAddress -Name $publicIpName -ResourceGroupName $rgName -ErrorVariable isIPExist -ErrorAction SilentlyContinue `


if (!$isIPExist) 
{
    Write-Output "Public IP exist"
    

    Write-Verbose "Deleting Public Ip: {$publicIpName}"

    Remove-AzureRmPublicIpAddress -Name $publicIpName -ResourceGroupName $rgName -Force
} 
else 
{
    Write-Output "Public IP does not exist"
}




Write-Verbose "Get list of Public IPs"
Write-Output "Public IP"


Get-AzureRmPublicIpAddress -ResourceGroupName $rgName `
    | Select-Object Name, IpAddress, @{label='FQDN';expression={$_.DnsSettings.Fqdn}}, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap



<#

Get-AzureRmPublicIpAddress `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap -GroupBy ResourceGroupName

#>






<#
## References


#>


