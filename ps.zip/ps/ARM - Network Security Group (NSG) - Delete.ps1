﻿
<# Network Security Group (NSG) - Delete #>

<#


#>


# Variables - Network Security Group (NSG)

$nsgShortName = "qweasdzxc"
$nsgSuffix = "-nsg"
$nsgName = "${nsgShortName}${nsgSuffix}"



Get-AzureRmNetworkSecurityGroup -Name $nsgName -ResourceGroupName $rgName -ErrorVariable isNSGExist -ErrorAction SilentlyContinue `


if (!$isNSGExist) 
{
    Write-Output "Network Security Group exist"
    

    Write-Verbose "Deleting Network Security Group (NSG): {$nsgName}"

    Remove-AzureRmNetworkSecurityGroup -Name $nsgName -ResourceGroupName $rgName -Force
} 
else 
{
    Write-Output "Network Security Group does not exist"
}



Write-Verbose "Get list of Network Security Group (NSG)"
Write-Output "Network Security Groups"


Get-AzureRmNetworkSecurityGroup -ResourceGroupName $rgName `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap


<#

Get-AzureRmNetworkSecurityGroup `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap -GroupBy ResourceGroupName

#>





<#
## References



#>
