﻿
## To Set Verbose output
$PSDefaultParameterValues['*:Verbose'] = $true


$rgShortName = "qweasdzxc"
$rgSuffix = "-rg"
$rgName = "${rgShortName}${rgSuffix}"


<# Availability Set (AS) - Delete #>

<#


#>


# Variables - Availability Set (AS)

$asShortName = "qweasdzxc"
$avSetSuffix = "-as"
$asName = "${asShortName}${avSetSuffix}"




Get-AzureRmAvailabilitySet -Name $asName -ResourceGroupName $rgName -ErrorVariable isASExist -ErrorAction SilentlyContinue `

if (!$isASExist) 
{
    Write-Output "Availability Set exist"
    

    Write-Verbose "Deleting Availability Set (AS): {$asName}"

    Remove-AzureRmAvailabilitySet -Name $asName -ResourceGroupName $rgName -Force
} 
else 
{
    Write-Output "Availability Set does not exist"
}




Write-Verbose "Get list of Availability Set"
Write-Output "Availability Sets"


Get-AzureRmAvailabilitySet -ResourceGroupName $rgName `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -Wrap 


<#

Get-AzureRmAvailabilitySet -ResourceGroupName $rgName `
    | Select-Object Name, ResourceGroupName, Location `
    | Format-Table -AutoSize -GroupBy ResourceGroupName -Wrap 

#>






<#
# References



#>
