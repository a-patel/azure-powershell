﻿

## To Set Verbose output
$PSDefaultParameterValues['*:Verbose'] = $true


# Variables - common

$rgShortName = "qweasdzxc"
$rgSuffix = "-rg"
$rgName = "${rgShortName}${rgSuffix}"



$lbShortName = "qweasdzxc"
$lbSuffix = "-lb"
$lbName = "${lbShortName}${lbSuffix}"

$lbRuleName = "TestNatRule"




<# Load Balancer (LB) - Remove NAT Rule #>

<#

Load Balancer (LB)
NAT Rule

Props:
NAT Rule Name
Load Balancer (LB) Name

#>



Get-AzureRmLoadBalancer -Name $lbName -ResourceGroupName $rgName -ErrorVariable isLBExist -ErrorAction SilentlyContinue `


if (!$isLBExist) 
{
    Write-Output "Load Balancer exist"
    
    

    Write-Verbose "Fetching Load Balancer (LB): {$lbName}"
    $lb = Get-AzureRmLoadBalancer -Name $lbName -ResourceGroupName $rgName 


    Write-Verbose "Removing NAT rule: {$lbRuleName} from Load Balancer (LB): {$lbName}"
    
    Remove-AzureRmLoadBalancerInboundNatRuleConfig -Name $lbRuleName -LoadBalancer $lb 

    Set-AzureRmLoadBalancer -LoadBalancer $lb
} 
else 
{
    Write-Output "Load Balancer does not exist"
}





<#
# References

https://docs.microsoft.com/en-us/azure/virtual-machines/windows/tutorial-load-balancer

#>


